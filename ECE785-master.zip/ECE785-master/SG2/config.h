// configuration

#ifndef CONFIG_H
#define CONFIG_H

#define PRE_SIN_COS (1)

#endif


