#include "Geometry.h"

extern int heading;
extern double speed;
extern int track;
extern double drift;

extern const PT_T waypoints[];