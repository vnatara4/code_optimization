#define CONFIG_A_REG 0
#define CONFIG_B_REG 1
#define MODE_REG 2
#define XH_REG 3
#define XL_REG 4
#define ZH_REG 5
#define ZL_REG 6
#define YH_REG 7
#define YL_REG 8
#define STATUS_REG 9
#define ID_REG_A 10
#define ID_REG_B 11
#define ID_REG_C 12

#define COMPASS_DEV_ADDR 30

#define CONTINUOUS_MEASUREMENT_MODE 0
#define SINGLE_MEASUREMENT_MODE 1
#define IDLE_MODE 3
